package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Iterator;

import com.capgemini.fms.exception.FMSException;

public class FeedbackDAO implements IFeedbackDAO {

	HashMap<String, Integer> MathFeedbackDetails= new HashMap<>();
	HashMap<String, Integer> EnglishFeedbackDetails= new HashMap<>();
	@Override
	public void addFeedbackDetails(String name, int rating, String subject) throws FMSException {
		if(subject.equals("Math")) {
			MathFeedbackDetails.put(name, rating);
		}
		else if(subject.equals("English")) {
			EnglishFeedbackDetails.put(name, rating);
		}
	}

	@Override
	public HashMap<String, Integer> getFeedbackReport() throws FMSException {
		HashMap<String, Integer> consolidatedMap= new HashMap<>();
		
		HashMap<String, Integer> a= new HashMap<>();
		
		HashMap<String, Integer> b= new HashMap<>();
		
		if(EnglishFeedbackDetails.keySet().size()>MathFeedbackDetails.keySet().size()) {
			a.putAll(EnglishFeedbackDetails);
			b.putAll(MathFeedbackDetails);
		}
		else
		{
			b.putAll(EnglishFeedbackDetails);
			a.putAll(MathFeedbackDetails);
		}
		
		Iterator<String> iterator= a.keySet().iterator();
		while(iterator.hasNext()) {
			String name= iterator.next();
			int rating= a.get(name);
			Iterator<String> iterator2= b.keySet().iterator();
			while(iterator2.hasNext()) {
				String name2= iterator2.next();
				int rating2= b.get(name2);
				if(name.equals(name2)) {
					if(rating>rating2)
					{consolidatedMap.put(name, rating);
					}
					else {
						consolidatedMap.put(name2, rating2);
				}
				}
				else
				consolidatedMap.put(name2, rating2);
			}
			
			consolidatedMap.put(name, rating);
		}
				return consolidatedMap;
	}

}
