package com.capgemini.fms.service;

import java.util.HashMap;
import java.util.regex.Pattern;

import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.dao.IFeedbackDAO;
import com.capgemini.fms.exception.FMSException;

public class FeedbackService implements IFeedbackService {
	
	IFeedbackDAO dao= new FeedbackDAO();
	
	@Override
	public void addFeedbackDetails(String name, int rating, String subject) throws FMSException {
		
		dao.addFeedbackDetails(name, rating, subject);
	}

	@Override
	public HashMap<String, Integer> getFeedbackReport() throws FMSException {
		if(dao.getFeedbackReport().size()<=0) {
			throw new FMSException("No record found");
		}
		else
		return dao.getFeedbackReport();
	}

	@Override
	public void validateName(String teacherName) throws FMSException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z]{4,9}";
		if (!Pattern.matches(nameRegEx, teacherName)) {
			throw new FMSException("First letter should be capital and length must be in between 5 to 10 \n");
		}
	}

	@Override
	public void validateRating(int rating) throws FMSException {
		if(rating>5||rating<1) {
			throw new FMSException("Invalid rating");
		}
	}

	@Override
	public void validateSubject(String topic) throws FMSException {
		if((topic.equals("Math")||(topic.equals("English")))){	
		}
		else
		{
			throw new FMSException("Subject can be either English or Math");
		}
	}
}
