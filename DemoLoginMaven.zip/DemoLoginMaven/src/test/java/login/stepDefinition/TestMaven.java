package login.stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestMaven {

	@Given("^User will enter valid details on www\\.amazon\\.com and will click login$")
	public void user_will_enter_valid_details_on_www_amazon_com_and_will_click_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User will click login$")
	public void user_will_click_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Details page should be shown$")
	public void details_page_should_be_shown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
