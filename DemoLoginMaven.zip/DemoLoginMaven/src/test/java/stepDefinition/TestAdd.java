package stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class TestAdd {

	@Given("^User has three even numbers$")
	public void user_has_three_even_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("user has even numbers 4 6 8");
	}

	@When("^User will add three even numbers$")
	public void user_will_add_three_even_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		Assert.assertEquals(18, (4+6+8));
	}

	@Then("^result is also even$")
	public void result_is_also_even() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("result is ="+"18");
	}


}
